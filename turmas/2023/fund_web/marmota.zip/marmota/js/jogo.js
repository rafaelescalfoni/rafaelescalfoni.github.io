const btnTeste = document.querySelector("#teste")

const removeMarmota = numBuraco => {

    console.log(numBuraco)
    const buraco = document.querySelector(`.hole${numBuraco}`)
    buraco.classList.remove("up")
}

btnTeste.addEventListener("click", function(){
    const numBuraco = Math.trunc(Math.random() * 6) + 1
    const buraco = document.querySelector(`.hole${numBuraco}`)
    buraco.classList.add("up")

    setTimeout(function() {
        removeMarmota(numBuraco)
    }, 3000)
})