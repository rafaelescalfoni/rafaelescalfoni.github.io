

window.onload = () => {

    //resposta da 1.
    let btInverteFrase = document.getElementById("inverteFrase");
    btInverteFrase.onclick = inverteFrase;
    
    //resposta da 2.
    let btNegritarVogal = document.getElementById("negritarVogal");
    btNegritarVogal.onclick = marcaVogal;

    //resposta da 3.
    let btContarPalavras = document.getElementById("contarPalavras");
    btContarPalavras.onclick = contarPalavras;

    let btResp6 = document.getElementById("calc6");
    btResp6.onclick = contarBatimentos;
}

function inverteFrase () {
    // pega valor digitado na caixa de texto
    let frase = document.getElementById("frase").value; 
            
    let fraseInvertida= "";
    for(let pos=frase.length-1; pos>=0; pos--) {
        fraseInvertida +=frase[pos];
    }
    document.getElementById("fraseDigitada").innerHTML = frase;
    document.getElementById("fraseInvertida").innerHTML = fraseInvertida;
}

function marcaVogal() {
    //pega a frase digitada

    //iterar a string da frase
        //("AEIOUaeiou").indexOf(caracter) =
        //se o caracter for vogal, exemplo, se for "a"
            //substituir o "a" por "<b>a</b>"
}

function contarPalavras() {
    // pegar frase digitada em frase3

    // transformar minha frase (que é String) em um array - usar split()
    // let listaPalavras....
    // let listaTermos...
    // iterar a lista de palavras 
    /* listaPalavras.forEach((palavra) => {
        // let termoExistente = listaTermos.find((termo) =>{
            return termo.palavra == palavra;
            });
        if(termoExistente) {// se undefined == false
            // se existir - incrementar a ocorrencia => termo.ocorrencia++
            termoExistente.ocorrencia++;
        } else {
            // criar uma lista de termos - {palavra, ocorrencias}
            listaTermos.push(new Termo(palavra));
        }
        
        // listaTermo = [{palavra:"Lorem", ocorrencia: 1}, {palavra:"ipsum", ocorrencia: 2},...]
    })
    alimentarTabela(listaTermo);
    */
}

// funcao para criar objetos termo (função construtora de objetos termo)
function Termo(palavra) {
    this.palavra = palavra;
    this.ocorrencia = 1;
}

function alimentarTabela(lista) {
    let tabela = document.getElementById("contagemPalavras");
    tabela.innerHTML += `<tr><th>Palavra</th><th>Ocorrências</th></tr>`;
    lista.forEach((termo )=> {
        tabela.innerHTML += `<tr><td>${termo.palavra}</td><td>${termo.ocorrencia}</td></tr>`;
    })
}
/* exercicio 5 */
function procurar(termo) {
    //pegar o texto em #frase5

    //trocar todas as ocorrencias do termo por <mark>termo</mark>

    // atualizar o resp5
}

function substituir(termo, termoSubstituto) {
    //pegar o texto em #frase5

    //trocar todas as ocorrencias do termo por termoSubstituto

    // atualizar o resp5
}

// resposta similar da 6

function contarBatimentos() {
    let dataNascimentoStr = document.getElementById("entrada6").value;
    let dataArray = dataNascimentoStr.split("-");
    let dataNascimento = new Date(dataArray[0], dataArray[1]-1, dataArray[2]);
    let dataAtual = new Date();
    //diferença em milisegundos
    let diferencaEmMilisegundos = dataAtual.getTime() - dataNascimento.getTime();
    console.log(diferencaEmMilisegundos);
    //considerando 60 batimentos por minuto
    let batimentos = diferencaEmMilisegundos/1000;
    document.getElementById("resp6").innerHTML = `Seu coração já bateu ${batimentos} vezes`;


}