/*
fatorial(5); // 5 * 4 * 3 * 2 * 1
fatorial(0); // retornar 1
fatorial(-5); // parâmetro inválido 

*/
function fatorial(numero){
    if(numero) return 1;
    if(numero <0 ) return "Parâmetro inválido";
    

} 

fatorial(12);