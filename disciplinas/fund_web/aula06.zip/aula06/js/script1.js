console.log(0.1+0.2);

console.log(Math.pow(2, 2));

console.trace("alô mundo!");