/*
let carros = [];
carros[0] = "Ka";
carros[1] = "Corsa";
carros[2] = "Palio";



let soma = (operador1, operador2) => {
    return operador1 + operador2;
}



function Pessoa(nome, dataNascimento, telefone, endereco) {
    this.nome = nome;
    this.dataNascimento = dataNascimento;
    this.telefone = telefone;
    this.endereco =  endereco;
}

Pessoa.prototype.getIdade = function() {return 19; };

let enderecoPadrao = {logradouro:"Rua 1", numero:2, bairro:"Centro"};

let ana = new Pessoa("Ana", new Date(2005, 00, 11), "(22)555-0000", enderecoPadrao);
let joao = new Pessoa("João", new Date(2003, 01, 21), "(22)555-0000", enderecoPadrao);
let maria = new Pessoa("Maria", new Date(2004, 01, 21), "(22)555-0000", enderecoPadrao);

console.log(ana);
console.log(joao);
console.log(maria.getIdade.apply(this));
*/

/* Trabalhando o DOM */
/*
let h1Obj = document.querySelector("#teste");

h1Obj.addEventListener("click", ()=>{mudaEstilo("#teste")});

//h1Obj.innerHTML = "<a href='https://www.google.com'>Alô</a> mundo";
h1Obj.classList.add("estilo1");

function mudaEstilo(objSelector) {
    let obj = document.querySelector(objSelector);
    obj.classList.toggle("estilo2");
}

function mudaMaiusculo(origemIpt, destinoP){
    destinoP.innerHTML = origemIpt.value.toUpperCase();
}

let texto = document.getElementById("texto");
console.log(texto);
let paragrafo = document.getElementById("resultado");


texto.addEventListener("keyup", ()=>{mudaMaiusculo(texto, paragrafo)});
texto.addEventListener("click", ()=>{mudaEstilo("#texto")});

*/

/* Implementação da lista de compras */
/*
let btAdicionar = document.getElementById("addItem");

btAdicionar.onclick = function() {
    let item = document.getElementById("texto").value;
    let li = `<li>${item}</li>`;
    let lista = document.getElementById("listaDeCompras");
    lista.innerHTML += li;
};
*/
/*
btAdicionar.addEventListener("click", function(){
    let item = document.getElementById("texto"); // atribuição por referência 
    let li = document.createElement("li"); // <li></li>
    let link = document.createElement("a");
    link.href = "#";
    link.classList.add("btn-apagar");
    link.innerHTML = "Apagar item";
    let conteudoNovo = document.createTextNode(item.value); // texto "recuperado do ipt.val"
    li.appendChild(conteudoNovo); //<li>recuperado do ipt.val</li>
    li.appendChild(link);
    let lista = document.getElementById("listaDeCompras");
    lista.appendChild(li);
    item.value="";
    document.getElementById("texto").value = "";
});

let lista = document.getElementById("listaDeCompras");

lista.addEventListener("click", function(evento) {
    
    if(evento.target.matches(".btn-apagar")) {
        let link = evento.target; // apontar para o link clicado
        link.parentNode.remove(); // apagar o elemento pai do link clicado
    }
    
})
*/

let btProcurar = document.getElementById("procurar");
let btSubstituir = document.getElementById("substituir");
let iptTermo = document.getElementById("termo");



btProcurar.onclick = function() {
    let termo = document.getElementById("termo").value;
    let resultado = document.getElementById("result");
    let resultadoStr = resultado.innerHTML;

    //removendo as antigas marcações
    resultadoStr = resultadoStr.replaceAll("<mark>", "");
    resultadoStr = resultadoStr.replaceAll("</mark>", "");

    //adicionando novas marcações no texto
    resultadoStr = resultadoStr.replaceAll(termo, `<mark>${termo}</mark>`);
    resultado.innerHTML = resultadoStr;
}

btSubstituir.onclick = function() {
    //recuperar o termo procurado
    //recuperar o termo substituto
    //substituir
}

let iptSenha = document.getElementById("senha");

iptSenha.onkeyup = function() {
    let status = document.getElementById( "status");
    status.innerHTML = "Senha Fraca";
    status.style.color = "red";
    let senhaDigitada = iptSenha.value;
    console.log("possui maiusculo?");
    console.log(temMaiusculo(senhaDigitada));
    console.log("possui caracter especial?");
    console.log(temCaracterEspecial(senhaDigitada));


}

function temMaiusculo(senha) {
    for(let indice = 0; indice < senha.length; indice++) {
        if ((senha.charCodeAt(indice)>=65 && senha.charCodeAt(indice) <= 90)) {
            return true;
        }
    }
    return false;
}

function eMinusculo(digito) {
    return (digito.charCodeAt(0)>=97 && digito.charCodeAt(0) <= 122);
}
function eNumero(digito) {
    return (digito.charCodeAt(0)>=48 && digito.charCodeAt(0) <= 57);
}

function temCaracterEspecial(senha) {
    for(let indice=0; indice < senha.length; indice++) {
        if(':,."&=!?[/{(]})'.indexOf(senha.charAt(indice)) != -1) return true;
    }
    return false;
}
